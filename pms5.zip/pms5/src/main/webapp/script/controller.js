app.controller("myController",function($scope,$http){
	
	
	$scope.getCategories=function(){
	var url="http://localhost:8088/pms5/ProductServlet?action=category";
	
	$http.get(url)
	.success(function(response){
		$scope.categories=response;
	})
	.error(function(msg){
		$scope.categories=msg;
	});
	
	};

	$scope.getSubCategories=function(){
	var url="http://localhost:8088/pms5/ProductServlet?action=subcategory";
	
	$http.get(url)
	.success(function(response){
		$scope.subcategories=response;
	})
	.error(function(msg){
		$scope.subcategories=msg;
	});
	
	};
	
	
	$scope.getSuppliers=function(){
		var url="http://localhost:8088/pms5/ProductServlet?action=supplier";
		
		$http.get(url)
		.success(function(response){
			$scope.suppliers=response;
		})
		.error(function(msg){
			$scope.suppliers=msg;
		});
		
		};
		
		
		
	$scope.getDiscounts=function(){
			var url="http://localhost:8088/pms5/ProductServlet?action=discount";
			
			$http.get(url)
			.success(function(response){
				$scope.discounts=response;
			})
			.error(function(msg){
				$scope.discounts=msg;
			});
			
			};
			
		
	
	
});


