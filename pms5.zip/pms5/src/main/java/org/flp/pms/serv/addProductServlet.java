package org.flp.pms.serv;


import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;



public class addProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer=response.getWriter();
		IProductDao pdao=new ProductDaoImplForMap();
		Category category=null;
		SubCategory subcategory=null;
		Supplier supplier=null;
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-DD");
		String productName=request.getParameter("pname");
		String description=request.getParameter("pdesc");
		String manufacturing_date=request.getParameter("manuDate");
		String expiry_date=request.getParameter("exDate");
		String max_retail_price=request.getParameter("mrp");
		String catName=request.getParameter("catName");
		String subName=request.getParameter("subcatName");
		String supplierName=request.getParameter("supplier");
		String discount=request.getParameter("discount");
	    String ratings=request.getParameter("rate");
		
		Product product=new Product();
		product.setProductName(productName);
		product.setDescription(description);
		product.setManufacturing_date(manufacturing_date);
		product.setExpiry_date(expiry_date);
		List<Category> categories=pdao.getAllCategory();
		for(Category c:categories)
		{
			if(c.getCategory_Name().equalsIgnoreCase(catName))
				category=c;
		}
		
		
		product.setCategory(category);
		List<SubCategory> subcategories=pdao.getAllSubCategory();
		for(SubCategory sub:subcategories)
		{
			if(sub.getSub_category_Name().equalsIgnoreCase(subName))
				subcategory=sub;
		}
	List<Supplier> suppliers=pdao.getAllSuppliers();
	
		for(com.flp.pms.domain.Supplier supl:suppliers)
		{
			if(supl.getFirstName().equalsIgnoreCase(supplierName))
				supplier=supl;
				
		}
		
		
		List<Supplier> suppliers=pdao.getAllSuppliers();
		
		for(com.flp.pms.domain.Supplier supl:suppliers)
		{
			if(supl.getFirstName().equalsIgnoreCase(supplierName))
				supplier=supl;
				
		}
		
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
